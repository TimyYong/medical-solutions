# -*- coding: utf-8 -*-
"""export_corpus.py —— 从「医疗信息化知识库-标准指标卡.xlsx」重新导出语料包。

每次扩库（往 Excel「指标卡总表」追加指标卡）后运行本脚本即可刷新：
    python export_corpus.py

生成/覆盖：
    cards.jsonl            16 键，UTF-8 无 BOM，一行一卡，保持表内顺序（不排序）
    索引-卡片总表.csv       11 列（沿用既有列结构），UTF-8 BOM
    索引-来源分组.csv       6 列，按来源序号首次出现顺序分组，UTF-8 BOM

不改动：
    索引-关键词.csv        （命中清单由独立流程重算，避免整表覆盖）
    主体与口语映射.csv

幂等：重复运行结果一致。
"""
import os, csv, json, collections

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
EXCEL = os.path.join(ROOT, "医疗信息化知识库-标准指标卡.xlsx")
SHEET = "指标卡总表"

# cards.jsonl 的 16 个规范键（与检索脚本 retrieval_v2.py 读取的键名一致）
# 注意：Excel 第 8/9 列表头是长名「原文口径（可引用原句）/判定标准（可量化/可核查）」，
# 导出到 cards.jsonl 时统一用短键「原文口径/判定标准」。
CARD_KEYS = [
    "卡号", "卡片类型", "来源序号", "来源文件", "文件层级", "指标维度", "指标项",
    "原文口径", "判定标准", "核查方式", "建议权重", "置信度", "原文链接",
    "获取渠道（实测可访问）", "数值来源", "同源卡",
]

# 索引-卡片总表.csv 的列（沿用现有 11 列结构）：列名 -> Excel 列号(1-based)
INDEX_COLS = [
    ("卡号", 1), ("卡片类型", 2), ("指标维度", 6), ("指标项", 7),
    ("来源序号", 3), ("来源文件", 4), ("置信度", 12), ("建议权重", 11),
    ("数值来源", 15), ("原文链接", 13), ("实测渠道", 14),
]


def read_excel_rows():
    import openpyxl
    wb = openpyxl.load_workbook(EXCEL, data_only=True)
    ws = wb[SHEET]
    rows = []
    r = 4  # 第 4 行起是数据
    while True:
        first = ws.cell(row=r, column=1).value
        if first is None or str(first).strip() == "":
            break
        vals = [ws.cell(row=r, column=c).value for c in range(1, 17)]
        rows.append(vals)
        r += 1
    return rows


def export_cards_jsonl(rows):
    out = os.path.join(HERE, "cards.jsonl")
    n = 0
    with open(out, "w", encoding="utf-8", newline="\n") as f:  # UTF-8 无 BOM
        for vals in rows:
            rec = {}
            for i, key in enumerate(CARD_KEYS):
                v = vals[i]
                # 空单元格：除「同源卡」导出为 null（与既有约定一致）外，其余按原值
                if v is None or (isinstance(v, str) and v.strip() == ""):
                    rec[key] = None if key == "同源卡" else v
                else:
                    rec[key] = v
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            n += 1
    return n


def export_card_index(rows):
    out = os.path.join(HERE, "索引-卡片总表.csv")
    with open(out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow([c for c, _ in INDEX_COLS])
        for vals in rows:
            w.writerow([("" if vals[col - 1] is None else vals[col - 1])
                        for _, col in INDEX_COLS])


def export_source_groups(rows):
    out = os.path.join(HERE, "索引-来源分组.csv")
    order = []
    groups = collections.OrderedDict()
    for vals in rows:
        src_no = vals[2]
        if src_no not in groups:
            order.append(src_no)
            groups[src_no] = {"来源文件": vals[3], "文件层级": vals[4],
                              "cards": [], "conf": collections.Counter()}
        g = groups[src_no]
        g["cards"].append(vals[0])
        # 置信度归一：取「（」前短标签，与既有索引约定一致
        raw_conf = str(vals[11] or "")
        label = raw_conf.split("（")[0].split("(")[0].strip() or raw_conf
        g["conf"][label] += 1
    with open(out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["来源序号", "来源文件", "文件层级", "卡数", "置信度分布", "卡号区间"])
        for src_no in order:
            g = groups[src_no]
            conf_dist = "/".join("%s %d" % (k, v) for k, v in g["conf"].items())
            rng = "%s—%s" % (g["cards"][0], g["cards"][-1])
            w.writerow([src_no, g["来源文件"], g["文件层级"], len(g["cards"]), conf_dist, rng])
    return len(order)


def count_keywords():
    p = os.path.join(HERE, "索引-关键词.csv")
    with open(p, encoding="utf-8-sig") as f:
        return sum(1 for _ in csv.reader(f)) - 1


def main():
    rows = read_excel_rows()
    n_cards = export_cards_jsonl(rows)
    export_card_index(rows)
    n_groups = export_source_groups(rows)
    n_terms = count_keywords()
    print("cards.jsonl 卡数：%d" % n_cards)
    print("来源组数：%d" % n_groups)
    print("关键词词数：%d" % n_terms)


if __name__ == "__main__":
    main()
